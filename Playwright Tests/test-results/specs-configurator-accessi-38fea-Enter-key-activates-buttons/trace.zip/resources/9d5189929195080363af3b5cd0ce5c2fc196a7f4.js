var a = { exports: {} };
/*!
  Copyright (c) 2018 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
(function(r) {
  (function() {
    var l = {}.hasOwnProperty;
    function t() {
      for (var e = [], n = 0; n < arguments.length; n++) {
        var s = arguments[n];
        if (!!s) {
          var o = typeof s;
          if (o === "string" || o === "number")
            e.push(s);
          else if (Array.isArray(s)) {
            if (s.length) {
              var f = t.apply(null, s);
              f && e.push(f);
            }
          } else if (o === "object")
            if (s.toString === Object.prototype.toString)
              for (var i in s)
                l.call(s, i) && s[i] && e.push(i);
            else
              e.push(s.toString());
        }
      }
      return e.join(" ");
    }
    r.exports ? (t.default = t, r.exports = t) : window.classNames = t;
  })();
})(a);
export {
  a as c
};
//# sourceMappingURL=classnames.76e0eef6.js.map
