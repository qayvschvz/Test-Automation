var o = "-ms-", Y = "-moz-", s = "-webkit-", cr = "comm", X = "rule", _ = "decl", tr = "@import", sr = "@keyframes", ir = Math.abs, y = String.fromCharCode, fr = Object.assign;
function or(r, c) {
  return (((c << 2 ^ b(r, 0)) << 2 ^ b(r, 1)) << 2 ^ b(r, 2)) << 2 ^ b(r, 3);
}
function nr(r) {
  return r.trim();
}
function ur(r, c) {
  return (r = c.exec(r)) ? r[0] : r;
}
function n(r, c, e) {
  return r.replace(c, e);
}
function J(r, c) {
  return r.indexOf(c);
}
function b(r, c) {
  return r.charCodeAt(c) | 0;
}
function B(r, c, e) {
  return r.slice(c, e);
}
function E(r) {
  return r.length;
}
function v(r) {
  return r.length;
}
function P(r, c) {
  return c.push(r), r;
}
function hr(r, c) {
  return r.map(c).join("");
}
var Z = 1, j = 1, er = 0, w = 0, f = 0, I = "";
function q(r, c, e, a, t, x, M) {
  return { value: r, root: c, parent: e, type: a, props: t, children: x, line: Z, column: j, length: M, return: "" };
}
function L(r, c) {
  return fr(q("", null, null, "", null, null, 0), r, { length: -r.length }, c);
}
function br() {
  return f;
}
function pr() {
  return f = w > 0 ? b(I, --w) : 0, j--, f === 10 && (j = 1, Z--), f;
}
function k() {
  return f = w < er ? b(I, w++) : 0, j++, f === 10 && (j = 1, Z++), f;
}
function T() {
  return b(I, w);
}
function U() {
  return w;
}
function G(r, c) {
  return B(I, r, c);
}
function Q(r) {
  switch (r) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function wr(r) {
  return Z = j = 1, er = E(I = r), w = 0, [];
}
function $r(r) {
  return I = "", r;
}
function H(r) {
  return nr(G(w - 1, V(r === 91 ? r + 2 : r === 40 ? r + 1 : r)));
}
function dr(r) {
  for (; (f = T()) && f < 33; )
    k();
  return Q(r) > 2 || Q(f) > 3 ? "" : " ";
}
function kr(r, c) {
  for (; --c && k() && !(f < 48 || f > 102 || f > 57 && f < 65 || f > 70 && f < 97); )
    ;
  return G(r, U() + (c < 6 && T() == 32 && k() == 32));
}
function V(r) {
  for (; k(); )
    switch (f) {
      case r:
        return w;
      case 34:
      case 39:
        r !== 34 && r !== 39 && V(f);
        break;
      case 40:
        r === 41 && V(r);
        break;
      case 92:
        k();
        break;
    }
  return w;
}
function xr(r, c) {
  for (; k() && r + f !== 47 + 10; )
    if (r + f === 42 + 42 && T() === 47)
      break;
  return "/*" + G(c, w - 1) + "*" + y(r === 47 ? r : k());
}
function gr(r) {
  for (; !Q(T()); )
    k();
  return G(r, w);
}
function Mr(r) {
  return $r(W("", null, null, null, [""], r = wr(r), 0, [0], r));
}
function W(r, c, e, a, t, x, M, p, K) {
  for (var m = 0, O = 0, u = M, R = 0, S = 0, C = 0, $ = 1, D = 1, d = 1, h = 0, z = "", F = t, A = x, g = a, i = z; D; )
    switch (C = h, h = k()) {
      case 40:
        if (C != 108 && i.charCodeAt(u - 1) == 58) {
          J(i += n(H(h), "&", "&\f"), "&\f") != -1 && (d = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        i += H(h);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        i += dr(C);
        break;
      case 92:
        i += kr(U() - 1, 7);
        continue;
      case 47:
        switch (T()) {
          case 42:
          case 47:
            P(Er(xr(k(), U()), c, e), K);
            break;
          default:
            i += "/";
        }
        break;
      case 123 * $:
        p[m++] = E(i) * d;
      case 125 * $:
      case 59:
      case 0:
        switch (h) {
          case 0:
          case 125:
            D = 0;
          case 59 + O:
            S > 0 && E(i) - u && P(S > 32 ? rr(i + ";", a, e, u - 1) : rr(n(i, " ", "") + ";", a, e, u - 2), K);
            break;
          case 59:
            i += ";";
          default:
            if (P(g = l(i, c, e, m, O, t, p, z, F = [], A = [], u), x), h === 123)
              if (O === 0)
                W(i, c, g, g, F, x, u, p, A);
              else
                switch (R) {
                  case 100:
                  case 109:
                  case 115:
                    W(r, g, g, a && P(l(r, g, g, 0, 0, t, p, z, t, F = [], u), A), t, A, u, p, a ? F : A);
                    break;
                  default:
                    W(i, g, g, g, [""], A, 0, p, A);
                }
        }
        m = O = S = 0, $ = d = 1, z = i = "", u = M;
        break;
      case 58:
        u = 1 + E(i), S = C;
      default:
        if ($ < 1) {
          if (h == 123)
            --$;
          else if (h == 125 && $++ == 0 && pr() == 125)
            continue;
        }
        switch (i += y(h), h * $) {
          case 38:
            d = O > 0 ? 1 : (i += "\f", -1);
            break;
          case 44:
            p[m++] = (E(i) - 1) * d, d = 1;
            break;
          case 64:
            T() === 45 && (i += H(k())), R = T(), O = u = E(z = i += gr(U())), h++;
            break;
          case 45:
            C === 45 && E(i) == 2 && ($ = 0);
        }
    }
  return x;
}
function l(r, c, e, a, t, x, M, p, K, m, O) {
  for (var u = t - 1, R = t === 0 ? x : [""], S = v(R), C = 0, $ = 0, D = 0; C < a; ++C)
    for (var d = 0, h = B(r, u + 1, u = ir($ = M[C])), z = r; d < S; ++d)
      (z = nr($ > 0 ? R[d] + " " + h : n(h, /&\f/g, R[d]))) && (K[D++] = z);
  return q(r, c, e, t === 0 ? X : p, K, m, O);
}
function Er(r, c, e) {
  return q(r, c, e, cr, y(br()), B(r, 2, -2), 0);
}
function rr(r, c, e, a) {
  return q(r, c, e, _, B(r, 0, a), B(r, a + 1, -1), a);
}
function ar(r, c) {
  switch (or(r, c)) {
    case 5103:
      return s + "print-" + r + r;
    case 5737:
    case 4201:
    case 3177:
    case 3433:
    case 1641:
    case 4457:
    case 2921:
    case 5572:
    case 6356:
    case 5844:
    case 3191:
    case 6645:
    case 3005:
    case 6391:
    case 5879:
    case 5623:
    case 6135:
    case 4599:
    case 4855:
    case 4215:
    case 6389:
    case 5109:
    case 5365:
    case 5621:
    case 3829:
      return s + r + r;
    case 5349:
    case 4246:
    case 4810:
    case 6968:
    case 2756:
      return s + r + Y + r + o + r + r;
    case 6828:
    case 4268:
      return s + r + o + r + r;
    case 6165:
      return s + r + o + "flex-" + r + r;
    case 5187:
      return s + r + n(r, /(\w+).+(:[^]+)/, s + "box-$1$2" + o + "flex-$1$2") + r;
    case 5443:
      return s + r + o + "flex-item-" + n(r, /flex-|-self/, "") + r;
    case 4675:
      return s + r + o + "flex-line-pack" + n(r, /align-content|flex-|-self/, "") + r;
    case 5548:
      return s + r + o + n(r, "shrink", "negative") + r;
    case 5292:
      return s + r + o + n(r, "basis", "preferred-size") + r;
    case 6060:
      return s + "box-" + n(r, "-grow", "") + s + r + o + n(r, "grow", "positive") + r;
    case 4554:
      return s + n(r, /([^-])(transform)/g, "$1" + s + "$2") + r;
    case 6187:
      return n(n(n(r, /(zoom-|grab)/, s + "$1"), /(image-set)/, s + "$1"), r, "") + r;
    case 5495:
    case 3959:
      return n(r, /(image-set\([^]*)/, s + "$1$`$1");
    case 4968:
      return n(n(r, /(.+:)(flex-)?(.*)/, s + "box-pack:$3" + o + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + s + r + r;
    case 4095:
    case 3583:
    case 4068:
    case 2532:
      return n(r, /(.+)-inline(.+)/, s + "$1$2") + r;
    case 8116:
    case 7059:
    case 5753:
    case 5535:
    case 5445:
    case 5701:
    case 4933:
    case 4677:
    case 5533:
    case 5789:
    case 5021:
    case 4765:
      if (E(r) - 1 - c > 6)
        switch (b(r, c + 1)) {
          case 109:
            if (b(r, c + 4) !== 45)
              break;
          case 102:
            return n(r, /(.+:)(.+)-([^]+)/, "$1" + s + "$2-$3$1" + Y + (b(r, c + 3) == 108 ? "$3" : "$2-$3")) + r;
          case 115:
            return ~J(r, "stretch") ? ar(n(r, "stretch", "fill-available"), c) + r : r;
        }
      break;
    case 4949:
      if (b(r, c + 1) !== 115)
        break;
    case 6444:
      switch (b(r, E(r) - 3 - (~J(r, "!important") && 10))) {
        case 107:
          return n(r, ":", ":" + s) + r;
        case 101:
          return n(r, /(.+:)([^;!]+)(;|!.+)?/, "$1" + s + (b(r, 14) === 45 ? "inline-" : "") + "box$3$1" + s + "$2$3$1" + o + "$2box$3") + r;
      }
      break;
    case 5936:
      switch (b(r, c + 11)) {
        case 114:
          return s + r + o + n(r, /[svh]\w+-[tblr]{2}/, "tb") + r;
        case 108:
          return s + r + o + n(r, /[svh]\w+-[tblr]{2}/, "tb-rl") + r;
        case 45:
          return s + r + o + n(r, /[svh]\w+-[tblr]{2}/, "lr") + r;
      }
      return s + r + o + r + r;
  }
  return r;
}
function N(r, c) {
  for (var e = "", a = v(r), t = 0; t < a; t++)
    e += c(r[t], t, r, c) || "";
  return e;
}
function Cr(r, c, e, a) {
  switch (r.type) {
    case tr:
    case _:
      return r.return = r.return || r.value;
    case cr:
      return "";
    case sr:
      return r.return = r.value + "{" + N(r.children, a) + "}";
    case X:
      r.value = r.props.join(",");
  }
  return E(e = N(r.children, a)) ? r.return = r.value + "{" + e + "}" : "";
}
function Or(r) {
  var c = v(r);
  return function(e, a, t, x) {
    for (var M = "", p = 0; p < c; p++)
      M += r[p](e, a, t, x) || "";
    return M;
  };
}
function zr(r) {
  return function(c) {
    c.root || (c = c.return) && r(c);
  };
}
function Ar(r, c, e, a) {
  if (r.length > -1 && !r.return)
    switch (r.type) {
      case _:
        r.return = ar(r.value, r.length);
        break;
      case sr:
        return N([L(r, { value: n(r.value, "@", "@" + s) })], a);
      case X:
        if (r.length)
          return hr(r.props, function(t) {
            switch (ur(t, /(::plac\w+|:read-\w+)/)) {
              case ":read-only":
              case ":read-write":
                return N([L(r, { props: [n(t, /:(read-\w+)/, ":" + Y + "$1")] })], a);
              case "::placeholder":
                return N([
                  L(r, { props: [n(t, /:(plac\w+)/, ":" + s + "input-$1")] }),
                  L(r, { props: [n(t, /:(plac\w+)/, ":" + Y + "$1")] }),
                  L(r, { props: [n(t, /:(plac\w+)/, o + "input-$1")] })
                ], a);
            }
            return "";
          });
    }
}
export {
  Cr as a,
  wr as b,
  Mr as c,
  $r as d,
  T as e,
  y as f,
  H as g,
  G as h,
  w as i,
  Or as m,
  k as n,
  Ar as p,
  zr as r,
  N as s,
  Q as t
};
//# sourceMappingURL=stylis.398e880d.js.map
