var R = "top", S = "bottom", T = "right", B = "left", Ae = "auto", fe = [R, S, T, B], G = "start", oe = "end", pt = "clippingParents", Je = "viewport", ne = "popper", ct = "reference", Ne = /* @__PURE__ */ fe.reduce(function(t, e) {
  return t.concat([e + "-" + G, e + "-" + oe]);
}, []), Ke = /* @__PURE__ */ [].concat(fe, [Ae]).reduce(function(t, e) {
  return t.concat([e, e + "-" + G, e + "-" + oe]);
}, []), ut = "beforeRead", lt = "read", vt = "afterRead", dt = "beforeMain", ht = "main", mt = "afterMain", gt = "beforeWrite", yt = "write", bt = "afterWrite", wt = [ut, lt, vt, dt, ht, mt, gt, yt, bt];
function F(t) {
  return t ? (t.nodeName || "").toLowerCase() : null;
}
function W(t) {
  if (t == null)
    return window;
  if (t.toString() !== "[object Window]") {
    var e = t.ownerDocument;
    return e && e.defaultView || window;
  }
  return t;
}
function J(t) {
  var e = W(t).Element;
  return t instanceof e || t instanceof Element;
}
function k(t) {
  var e = W(t).HTMLElement;
  return t instanceof e || t instanceof HTMLElement;
}
function Pe(t) {
  if (typeof ShadowRoot > "u")
    return !1;
  var e = W(t).ShadowRoot;
  return t instanceof e || t instanceof ShadowRoot;
}
function xt(t) {
  var e = t.state;
  Object.keys(e.elements).forEach(function(r) {
    var n = e.styles[r] || {}, a = e.attributes[r] || {}, i = e.elements[r];
    !k(i) || !F(i) || (Object.assign(i.style, n), Object.keys(a).forEach(function(o) {
      var s = a[o];
      s === !1 ? i.removeAttribute(o) : i.setAttribute(o, s === !0 ? "" : s);
    }));
  });
}
function Ot(t) {
  var e = t.state, r = {
    popper: {
      position: e.options.strategy,
      left: "0",
      top: "0",
      margin: "0"
    },
    arrow: {
      position: "absolute"
    },
    reference: {}
  };
  return Object.assign(e.elements.popper.style, r.popper), e.styles = r, e.elements.arrow && Object.assign(e.elements.arrow.style, r.arrow), function() {
    Object.keys(e.elements).forEach(function(n) {
      var a = e.elements[n], i = e.attributes[n] || {}, o = Object.keys(e.styles.hasOwnProperty(n) ? e.styles[n] : r[n]), s = o.reduce(function(f, c) {
        return f[c] = "", f;
      }, {});
      !k(a) || !F(a) || (Object.assign(a.style, s), Object.keys(i).forEach(function(f) {
        a.removeAttribute(f);
      }));
    });
  };
}
const Et = {
  name: "applyStyles",
  enabled: !0,
  phase: "write",
  fn: xt,
  effect: Ot,
  requires: ["computeStyles"]
};
function H(t) {
  return t.split("-")[0];
}
var z = Math.max, ge = Math.min, K = Math.round;
function Q(t, e) {
  e === void 0 && (e = !1);
  var r = t.getBoundingClientRect(), n = 1, a = 1;
  if (k(t) && e) {
    var i = t.offsetHeight, o = t.offsetWidth;
    o > 0 && (n = K(r.width) / o || 1), i > 0 && (a = K(r.height) / i || 1);
  }
  return {
    width: r.width / n,
    height: r.height / a,
    top: r.top / a,
    right: r.right / n,
    bottom: r.bottom / a,
    left: r.left / n,
    x: r.left / n,
    y: r.top / a
  };
}
function De(t) {
  var e = Q(t), r = t.offsetWidth, n = t.offsetHeight;
  return Math.abs(e.width - r) <= 1 && (r = e.width), Math.abs(e.height - n) <= 1 && (n = e.height), {
    x: t.offsetLeft,
    y: t.offsetTop,
    width: r,
    height: n
  };
}
function Qe(t, e) {
  var r = e.getRootNode && e.getRootNode();
  if (t.contains(e))
    return !0;
  if (r && Pe(r)) {
    var n = e;
    do {
      if (n && t.isSameNode(n))
        return !0;
      n = n.parentNode || n.host;
    } while (n);
  }
  return !1;
}
function N(t) {
  return W(t).getComputedStyle(t);
}
function At(t) {
  return ["table", "td", "th"].indexOf(F(t)) >= 0;
}
function q(t) {
  return ((J(t) ? t.ownerDocument : t.document) || window.document).documentElement;
}
function ye(t) {
  return F(t) === "html" ? t : t.assignedSlot || t.parentNode || (Pe(t) ? t.host : null) || q(t);
}
function Ve(t) {
  return !k(t) || N(t).position === "fixed" ? null : t.offsetParent;
}
function Pt(t) {
  var e = navigator.userAgent.toLowerCase().indexOf("firefox") !== -1, r = navigator.userAgent.indexOf("Trident") !== -1;
  if (r && k(t)) {
    var n = N(t);
    if (n.position === "fixed")
      return null;
  }
  var a = ye(t);
  for (Pe(a) && (a = a.host); k(a) && ["html", "body"].indexOf(F(a)) < 0; ) {
    var i = N(a);
    if (i.transform !== "none" || i.perspective !== "none" || i.contain === "paint" || ["transform", "perspective"].indexOf(i.willChange) !== -1 || e && i.willChange === "filter" || e && i.filter && i.filter !== "none")
      return a;
    a = a.parentNode;
  }
  return null;
}
function pe(t) {
  for (var e = W(t), r = Ve(t); r && At(r) && N(r).position === "static"; )
    r = Ve(r);
  return r && (F(r) === "html" || F(r) === "body" && N(r).position === "static") ? e : r || Pt(t) || e;
}
function je(t) {
  return ["top", "bottom"].indexOf(t) >= 0 ? "x" : "y";
}
function ae(t, e, r) {
  return z(t, ge(e, r));
}
function Dt(t, e, r) {
  var n = ae(t, e, r);
  return n > r ? r : n;
}
function Ze() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}
function _e(t) {
  return Object.assign({}, Ze(), t);
}
function et(t, e) {
  return e.reduce(function(r, n) {
    return r[n] = t, r;
  }, {});
}
var jt = function(e, r) {
  return e = typeof e == "function" ? e(Object.assign({}, r.rects, {
    placement: r.placement
  })) : e, _e(typeof e != "number" ? e : et(e, fe));
};
function Rt(t) {
  var e, r = t.state, n = t.name, a = t.options, i = r.elements.arrow, o = r.modifiersData.popperOffsets, s = H(r.placement), f = je(s), c = [B, T].indexOf(s) >= 0, p = c ? "height" : "width";
  if (!(!i || !o)) {
    var m = jt(a.padding, r), E = De(i), u = f === "y" ? R : B, g = f === "y" ? S : T, v = r.rects.reference[p] + r.rects.reference[f] - o[f] - r.rects.popper[p], d = o[f] - r.rects.reference[f], w = pe(i), x = w ? f === "y" ? w.clientHeight || 0 : w.clientWidth || 0 : 0, O = v / 2 - d / 2, l = m[u], y = x - E[p] - m[g], h = x / 2 - E[p] / 2 + O, b = ae(l, h, y), A = f;
    r.modifiersData[n] = (e = {}, e[A] = b, e.centerOffset = b - h, e);
  }
}
function Bt(t) {
  var e = t.state, r = t.options, n = r.element, a = n === void 0 ? "[data-popper-arrow]" : n;
  a != null && (typeof a == "string" && (a = e.elements.popper.querySelector(a), !a) || !Qe(e.elements.popper, a) || (e.elements.arrow = a));
}
const Ct = {
  name: "arrow",
  enabled: !0,
  phase: "main",
  fn: Rt,
  effect: Bt,
  requires: ["popperOffsets"],
  requiresIfExists: ["preventOverflow"]
};
function Z(t) {
  return t.split("-")[1];
}
var $t = {
  top: "auto",
  right: "auto",
  bottom: "auto",
  left: "auto"
};
function kt(t) {
  var e = t.x, r = t.y, n = window, a = n.devicePixelRatio || 1;
  return {
    x: K(e * a) / a || 0,
    y: K(r * a) / a || 0
  };
}
function qe(t) {
  var e, r = t.popper, n = t.popperRect, a = t.placement, i = t.variation, o = t.offsets, s = t.position, f = t.gpuAcceleration, c = t.adaptive, p = t.roundOffsets, m = t.isFixed, E = o.x, u = E === void 0 ? 0 : E, g = o.y, v = g === void 0 ? 0 : g, d = typeof p == "function" ? p({
    x: u,
    y: v
  }) : {
    x: u,
    y: v
  };
  u = d.x, v = d.y;
  var w = o.hasOwnProperty("x"), x = o.hasOwnProperty("y"), O = B, l = R, y = window;
  if (c) {
    var h = pe(r), b = "clientHeight", A = "clientWidth";
    if (h === W(r) && (h = q(r), N(h).position !== "static" && s === "absolute" && (b = "scrollHeight", A = "scrollWidth")), h = h, a === R || (a === B || a === T) && i === oe) {
      l = S;
      var j = m && h === y && y.visualViewport ? y.visualViewport.height : h[b];
      v -= j - n.height, v *= f ? 1 : -1;
    }
    if (a === B || (a === R || a === S) && i === oe) {
      O = T;
      var P = m && h === y && y.visualViewport ? y.visualViewport.width : h[A];
      u -= P - n.width, u *= f ? 1 : -1;
    }
  }
  var D = Object.assign({
    position: s
  }, c && $t), L = p === !0 ? kt({
    x: u,
    y: v
  }) : {
    x: u,
    y: v
  };
  if (u = L.x, v = L.y, f) {
    var C;
    return Object.assign({}, D, (C = {}, C[l] = x ? "0" : "", C[O] = w ? "0" : "", C.transform = (y.devicePixelRatio || 1) <= 1 ? "translate(" + u + "px, " + v + "px)" : "translate3d(" + u + "px, " + v + "px, 0)", C));
  }
  return Object.assign({}, D, (e = {}, e[l] = x ? v + "px" : "", e[O] = w ? u + "px" : "", e.transform = "", e));
}
function St(t) {
  var e = t.state, r = t.options, n = r.gpuAcceleration, a = n === void 0 ? !0 : n, i = r.adaptive, o = i === void 0 ? !0 : i, s = r.roundOffsets, f = s === void 0 ? !0 : s, c = {
    placement: H(e.placement),
    variation: Z(e.placement),
    popper: e.elements.popper,
    popperRect: e.rects.popper,
    gpuAcceleration: a,
    isFixed: e.options.strategy === "fixed"
  };
  e.modifiersData.popperOffsets != null && (e.styles.popper = Object.assign({}, e.styles.popper, qe(Object.assign({}, c, {
    offsets: e.modifiersData.popperOffsets,
    position: e.options.strategy,
    adaptive: o,
    roundOffsets: f
  })))), e.modifiersData.arrow != null && (e.styles.arrow = Object.assign({}, e.styles.arrow, qe(Object.assign({}, c, {
    offsets: e.modifiersData.arrow,
    position: "absolute",
    adaptive: !1,
    roundOffsets: f
  })))), e.attributes.popper = Object.assign({}, e.attributes.popper, {
    "data-popper-placement": e.placement
  });
}
const Tt = {
  name: "computeStyles",
  enabled: !0,
  phase: "beforeWrite",
  fn: St,
  data: {}
};
var he = {
  passive: !0
};
function Lt(t) {
  var e = t.state, r = t.instance, n = t.options, a = n.scroll, i = a === void 0 ? !0 : a, o = n.resize, s = o === void 0 ? !0 : o, f = W(e.elements.popper), c = [].concat(e.scrollParents.reference, e.scrollParents.popper);
  return i && c.forEach(function(p) {
    p.addEventListener("scroll", r.update, he);
  }), s && f.addEventListener("resize", r.update, he), function() {
    i && c.forEach(function(p) {
      p.removeEventListener("scroll", r.update, he);
    }), s && f.removeEventListener("resize", r.update, he);
  };
}
const Mt = {
  name: "eventListeners",
  enabled: !0,
  phase: "write",
  fn: function() {
  },
  effect: Lt,
  data: {}
};
var Wt = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function me(t) {
  return t.replace(/left|right|bottom|top/g, function(e) {
    return Wt[e];
  });
}
var Ht = {
  start: "end",
  end: "start"
};
function Xe(t) {
  return t.replace(/start|end/g, function(e) {
    return Ht[e];
  });
}
function Re(t) {
  var e = W(t), r = e.pageXOffset, n = e.pageYOffset;
  return {
    scrollLeft: r,
    scrollTop: n
  };
}
function Be(t) {
  return Q(q(t)).left + Re(t).scrollLeft;
}
function Ft(t) {
  var e = W(t), r = q(t), n = e.visualViewport, a = r.clientWidth, i = r.clientHeight, o = 0, s = 0;
  return n && (a = n.width, i = n.height, /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || (o = n.offsetLeft, s = n.offsetTop)), {
    width: a,
    height: i,
    x: o + Be(t),
    y: s
  };
}
function Nt(t) {
  var e, r = q(t), n = Re(t), a = (e = t.ownerDocument) == null ? void 0 : e.body, i = z(r.scrollWidth, r.clientWidth, a ? a.scrollWidth : 0, a ? a.clientWidth : 0), o = z(r.scrollHeight, r.clientHeight, a ? a.scrollHeight : 0, a ? a.clientHeight : 0), s = -n.scrollLeft + Be(t), f = -n.scrollTop;
  return N(a || r).direction === "rtl" && (s += z(r.clientWidth, a ? a.clientWidth : 0) - i), {
    width: i,
    height: o,
    x: s,
    y: f
  };
}
function Ce(t) {
  var e = N(t), r = e.overflow, n = e.overflowX, a = e.overflowY;
  return /auto|scroll|overlay|hidden/.test(r + a + n);
}
function tt(t) {
  return ["html", "body", "#document"].indexOf(F(t)) >= 0 ? t.ownerDocument.body : k(t) && Ce(t) ? t : tt(ye(t));
}
function ie(t, e) {
  var r;
  e === void 0 && (e = []);
  var n = tt(t), a = n === ((r = t.ownerDocument) == null ? void 0 : r.body), i = W(n), o = a ? [i].concat(i.visualViewport || [], Ce(n) ? n : []) : n, s = e.concat(o);
  return a ? s : s.concat(ie(ye(o)));
}
function Ee(t) {
  return Object.assign({}, t, {
    left: t.x,
    top: t.y,
    right: t.x + t.width,
    bottom: t.y + t.height
  });
}
function Vt(t) {
  var e = Q(t);
  return e.top = e.top + t.clientTop, e.left = e.left + t.clientLeft, e.bottom = e.top + t.clientHeight, e.right = e.left + t.clientWidth, e.width = t.clientWidth, e.height = t.clientHeight, e.x = e.left, e.y = e.top, e;
}
function Ie(t, e) {
  return e === Je ? Ee(Ft(t)) : J(e) ? Vt(e) : Ee(Nt(q(t)));
}
function qt(t) {
  var e = ie(ye(t)), r = ["absolute", "fixed"].indexOf(N(t).position) >= 0, n = r && k(t) ? pe(t) : t;
  return J(n) ? e.filter(function(a) {
    return J(a) && Qe(a, n) && F(a) !== "body";
  }) : [];
}
function Xt(t, e, r) {
  var n = e === "clippingParents" ? qt(t) : [].concat(e), a = [].concat(n, [r]), i = a[0], o = a.reduce(function(s, f) {
    var c = Ie(t, f);
    return s.top = z(c.top, s.top), s.right = ge(c.right, s.right), s.bottom = ge(c.bottom, s.bottom), s.left = z(c.left, s.left), s;
  }, Ie(t, i));
  return o.width = o.right - o.left, o.height = o.bottom - o.top, o.x = o.left, o.y = o.top, o;
}
function rt(t) {
  var e = t.reference, r = t.element, n = t.placement, a = n ? H(n) : null, i = n ? Z(n) : null, o = e.x + e.width / 2 - r.width / 2, s = e.y + e.height / 2 - r.height / 2, f;
  switch (a) {
    case R:
      f = {
        x: o,
        y: e.y - r.height
      };
      break;
    case S:
      f = {
        x: o,
        y: e.y + e.height
      };
      break;
    case T:
      f = {
        x: e.x + e.width,
        y: s
      };
      break;
    case B:
      f = {
        x: e.x - r.width,
        y: s
      };
      break;
    default:
      f = {
        x: e.x,
        y: e.y
      };
  }
  var c = a ? je(a) : null;
  if (c != null) {
    var p = c === "y" ? "height" : "width";
    switch (i) {
      case G:
        f[c] = f[c] - (e[p] / 2 - r[p] / 2);
        break;
      case oe:
        f[c] = f[c] + (e[p] / 2 - r[p] / 2);
        break;
    }
  }
  return f;
}
function se(t, e) {
  e === void 0 && (e = {});
  var r = e, n = r.placement, a = n === void 0 ? t.placement : n, i = r.boundary, o = i === void 0 ? pt : i, s = r.rootBoundary, f = s === void 0 ? Je : s, c = r.elementContext, p = c === void 0 ? ne : c, m = r.altBoundary, E = m === void 0 ? !1 : m, u = r.padding, g = u === void 0 ? 0 : u, v = _e(typeof g != "number" ? g : et(g, fe)), d = p === ne ? ct : ne, w = t.rects.popper, x = t.elements[E ? d : p], O = Xt(J(x) ? x : x.contextElement || q(t.elements.popper), o, f), l = Q(t.elements.reference), y = rt({
    reference: l,
    element: w,
    strategy: "absolute",
    placement: a
  }), h = Ee(Object.assign({}, w, y)), b = p === ne ? h : l, A = {
    top: O.top - b.top + v.top,
    bottom: b.bottom - O.bottom + v.bottom,
    left: O.left - b.left + v.left,
    right: b.right - O.right + v.right
  }, j = t.modifiersData.offset;
  if (p === ne && j) {
    var P = j[a];
    Object.keys(A).forEach(function(D) {
      var L = [T, S].indexOf(D) >= 0 ? 1 : -1, C = [R, S].indexOf(D) >= 0 ? "y" : "x";
      A[D] += P[C] * L;
    });
  }
  return A;
}
function It(t, e) {
  e === void 0 && (e = {});
  var r = e, n = r.placement, a = r.boundary, i = r.rootBoundary, o = r.padding, s = r.flipVariations, f = r.allowedAutoPlacements, c = f === void 0 ? Ke : f, p = Z(n), m = p ? s ? Ne : Ne.filter(function(g) {
    return Z(g) === p;
  }) : fe, E = m.filter(function(g) {
    return c.indexOf(g) >= 0;
  });
  E.length === 0 && (E = m);
  var u = E.reduce(function(g, v) {
    return g[v] = se(t, {
      placement: v,
      boundary: a,
      rootBoundary: i,
      padding: o
    })[H(v)], g;
  }, {});
  return Object.keys(u).sort(function(g, v) {
    return u[g] - u[v];
  });
}
function Yt(t) {
  if (H(t) === Ae)
    return [];
  var e = me(t);
  return [Xe(t), e, Xe(e)];
}
function zt(t) {
  var e = t.state, r = t.options, n = t.name;
  if (!e.modifiersData[n]._skip) {
    for (var a = r.mainAxis, i = a === void 0 ? !0 : a, o = r.altAxis, s = o === void 0 ? !0 : o, f = r.fallbackPlacements, c = r.padding, p = r.boundary, m = r.rootBoundary, E = r.altBoundary, u = r.flipVariations, g = u === void 0 ? !0 : u, v = r.allowedAutoPlacements, d = e.options.placement, w = H(d), x = w === d, O = f || (x || !g ? [me(d)] : Yt(d)), l = [d].concat(O).reduce(function(U, V) {
      return U.concat(H(V) === Ae ? It(e, {
        placement: V,
        boundary: p,
        rootBoundary: m,
        padding: c,
        flipVariations: g,
        allowedAutoPlacements: v
      }) : V);
    }, []), y = e.rects.reference, h = e.rects.popper, b = /* @__PURE__ */ new Map(), A = !0, j = l[0], P = 0; P < l.length; P++) {
      var D = l[P], L = H(D), C = Z(D) === G, _ = [R, S].indexOf(L) >= 0, ee = _ ? "width" : "height", $ = se(e, {
        placement: D,
        boundary: p,
        rootBoundary: m,
        altBoundary: E,
        padding: c
      }), M = _ ? C ? T : B : C ? S : R;
      y[ee] > h[ee] && (M = me(M));
      var ce = me(M), X = [];
      if (i && X.push($[L] <= 0), s && X.push($[M] <= 0, $[ce] <= 0), X.every(function(U) {
        return U;
      })) {
        j = D, A = !1;
        break;
      }
      b.set(D, X);
    }
    if (A)
      for (var ue = g ? 3 : 1, be = function(V) {
        var re = l.find(function(ve) {
          var I = b.get(ve);
          if (I)
            return I.slice(0, V).every(function(we) {
              return we;
            });
        });
        if (re)
          return j = re, "break";
      }, te = ue; te > 0; te--) {
        var le = be(te);
        if (le === "break")
          break;
      }
    e.placement !== j && (e.modifiersData[n]._skip = !0, e.placement = j, e.reset = !0);
  }
}
const Ut = {
  name: "flip",
  enabled: !0,
  phase: "main",
  fn: zt,
  requiresIfExists: ["offset"],
  data: {
    _skip: !1
  }
};
function Ye(t, e, r) {
  return r === void 0 && (r = {
    x: 0,
    y: 0
  }), {
    top: t.top - e.height - r.y,
    right: t.right - e.width + r.x,
    bottom: t.bottom - e.height + r.y,
    left: t.left - e.width - r.x
  };
}
function ze(t) {
  return [R, T, S, B].some(function(e) {
    return t[e] >= 0;
  });
}
function Gt(t) {
  var e = t.state, r = t.name, n = e.rects.reference, a = e.rects.popper, i = e.modifiersData.preventOverflow, o = se(e, {
    elementContext: "reference"
  }), s = se(e, {
    altBoundary: !0
  }), f = Ye(o, n), c = Ye(s, a, i), p = ze(f), m = ze(c);
  e.modifiersData[r] = {
    referenceClippingOffsets: f,
    popperEscapeOffsets: c,
    isReferenceHidden: p,
    hasPopperEscaped: m
  }, e.attributes.popper = Object.assign({}, e.attributes.popper, {
    "data-popper-reference-hidden": p,
    "data-popper-escaped": m
  });
}
const Jt = {
  name: "hide",
  enabled: !0,
  phase: "main",
  requiresIfExists: ["preventOverflow"],
  fn: Gt
};
function Kt(t, e, r) {
  var n = H(t), a = [B, R].indexOf(n) >= 0 ? -1 : 1, i = typeof r == "function" ? r(Object.assign({}, e, {
    placement: t
  })) : r, o = i[0], s = i[1];
  return o = o || 0, s = (s || 0) * a, [B, T].indexOf(n) >= 0 ? {
    x: s,
    y: o
  } : {
    x: o,
    y: s
  };
}
function Qt(t) {
  var e = t.state, r = t.options, n = t.name, a = r.offset, i = a === void 0 ? [0, 0] : a, o = Ke.reduce(function(p, m) {
    return p[m] = Kt(m, e.rects, i), p;
  }, {}), s = o[e.placement], f = s.x, c = s.y;
  e.modifiersData.popperOffsets != null && (e.modifiersData.popperOffsets.x += f, e.modifiersData.popperOffsets.y += c), e.modifiersData[n] = o;
}
const Zt = {
  name: "offset",
  enabled: !0,
  phase: "main",
  requires: ["popperOffsets"],
  fn: Qt
};
function _t(t) {
  var e = t.state, r = t.name;
  e.modifiersData[r] = rt({
    reference: e.rects.reference,
    element: e.rects.popper,
    strategy: "absolute",
    placement: e.placement
  });
}
const er = {
  name: "popperOffsets",
  enabled: !0,
  phase: "read",
  fn: _t,
  data: {}
};
function tr(t) {
  return t === "x" ? "y" : "x";
}
function rr(t) {
  var e = t.state, r = t.options, n = t.name, a = r.mainAxis, i = a === void 0 ? !0 : a, o = r.altAxis, s = o === void 0 ? !1 : o, f = r.boundary, c = r.rootBoundary, p = r.altBoundary, m = r.padding, E = r.tether, u = E === void 0 ? !0 : E, g = r.tetherOffset, v = g === void 0 ? 0 : g, d = se(e, {
    boundary: f,
    rootBoundary: c,
    padding: m,
    altBoundary: p
  }), w = H(e.placement), x = Z(e.placement), O = !x, l = je(w), y = tr(l), h = e.modifiersData.popperOffsets, b = e.rects.reference, A = e.rects.popper, j = typeof v == "function" ? v(Object.assign({}, e.rects, {
    placement: e.placement
  })) : v, P = typeof j == "number" ? {
    mainAxis: j,
    altAxis: j
  } : Object.assign({
    mainAxis: 0,
    altAxis: 0
  }, j), D = e.modifiersData.offset ? e.modifiersData.offset[e.placement] : null, L = {
    x: 0,
    y: 0
  };
  if (!!h) {
    if (i) {
      var C, _ = l === "y" ? R : B, ee = l === "y" ? S : T, $ = l === "y" ? "height" : "width", M = h[l], ce = M + d[_], X = M - d[ee], ue = u ? -A[$] / 2 : 0, be = x === G ? b[$] : A[$], te = x === G ? -A[$] : -b[$], le = e.elements.arrow, U = u && le ? De(le) : {
        width: 0,
        height: 0
      }, V = e.modifiersData["arrow#persistent"] ? e.modifiersData["arrow#persistent"].padding : Ze(), re = V[_], ve = V[ee], I = ae(0, b[$], U[$]), we = O ? b[$] / 2 - ue - I - re - P.mainAxis : be - I - re - P.mainAxis, nt = O ? -b[$] / 2 + ue + I + ve + P.mainAxis : te + I + ve + P.mainAxis, xe = e.elements.arrow && pe(e.elements.arrow), at = xe ? l === "y" ? xe.clientTop || 0 : xe.clientLeft || 0 : 0, $e = (C = D == null ? void 0 : D[l]) != null ? C : 0, it = M + we - $e - at, ot = M + nt - $e, ke = ae(u ? ge(ce, it) : ce, M, u ? z(X, ot) : X);
      h[l] = ke, L[l] = ke - M;
    }
    if (s) {
      var Se, st = l === "x" ? R : B, ft = l === "x" ? S : T, Y = h[y], de = y === "y" ? "height" : "width", Te = Y + d[st], Le = Y - d[ft], Oe = [R, B].indexOf(w) !== -1, Me = (Se = D == null ? void 0 : D[y]) != null ? Se : 0, We = Oe ? Te : Y - b[de] - A[de] - Me + P.altAxis, He = Oe ? Y + b[de] + A[de] - Me - P.altAxis : Le, Fe = u && Oe ? Dt(We, Y, He) : ae(u ? We : Te, Y, u ? He : Le);
      h[y] = Fe, L[y] = Fe - Y;
    }
    e.modifiersData[n] = L;
  }
}
const nr = {
  name: "preventOverflow",
  enabled: !0,
  phase: "main",
  fn: rr,
  requiresIfExists: ["offset"]
};
function ar(t) {
  return {
    scrollLeft: t.scrollLeft,
    scrollTop: t.scrollTop
  };
}
function ir(t) {
  return t === W(t) || !k(t) ? Re(t) : ar(t);
}
function or(t) {
  var e = t.getBoundingClientRect(), r = K(e.width) / t.offsetWidth || 1, n = K(e.height) / t.offsetHeight || 1;
  return r !== 1 || n !== 1;
}
function sr(t, e, r) {
  r === void 0 && (r = !1);
  var n = k(e), a = k(e) && or(e), i = q(e), o = Q(t, a), s = {
    scrollLeft: 0,
    scrollTop: 0
  }, f = {
    x: 0,
    y: 0
  };
  return (n || !n && !r) && ((F(e) !== "body" || Ce(i)) && (s = ir(e)), k(e) ? (f = Q(e, !0), f.x += e.clientLeft, f.y += e.clientTop) : i && (f.x = Be(i))), {
    x: o.left + s.scrollLeft - f.x,
    y: o.top + s.scrollTop - f.y,
    width: o.width,
    height: o.height
  };
}
function fr(t) {
  var e = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), n = [];
  t.forEach(function(i) {
    e.set(i.name, i);
  });
  function a(i) {
    r.add(i.name);
    var o = [].concat(i.requires || [], i.requiresIfExists || []);
    o.forEach(function(s) {
      if (!r.has(s)) {
        var f = e.get(s);
        f && a(f);
      }
    }), n.push(i);
  }
  return t.forEach(function(i) {
    r.has(i.name) || a(i);
  }), n;
}
function pr(t) {
  var e = fr(t);
  return wt.reduce(function(r, n) {
    return r.concat(e.filter(function(a) {
      return a.phase === n;
    }));
  }, []);
}
function cr(t) {
  var e;
  return function() {
    return e || (e = new Promise(function(r) {
      Promise.resolve().then(function() {
        e = void 0, r(t());
      });
    })), e;
  };
}
function ur(t) {
  var e = t.reduce(function(r, n) {
    var a = r[n.name];
    return r[n.name] = a ? Object.assign({}, a, n, {
      options: Object.assign({}, a.options, n.options),
      data: Object.assign({}, a.data, n.data)
    }) : n, r;
  }, {});
  return Object.keys(e).map(function(r) {
    return e[r];
  });
}
var Ue = {
  placement: "bottom",
  modifiers: [],
  strategy: "absolute"
};
function Ge() {
  for (var t = arguments.length, e = new Array(t), r = 0; r < t; r++)
    e[r] = arguments[r];
  return !e.some(function(n) {
    return !(n && typeof n.getBoundingClientRect == "function");
  });
}
function lr(t) {
  t === void 0 && (t = {});
  var e = t, r = e.defaultModifiers, n = r === void 0 ? [] : r, a = e.defaultOptions, i = a === void 0 ? Ue : a;
  return function(s, f, c) {
    c === void 0 && (c = i);
    var p = {
      placement: "bottom",
      orderedModifiers: [],
      options: Object.assign({}, Ue, i),
      modifiersData: {},
      elements: {
        reference: s,
        popper: f
      },
      attributes: {},
      styles: {}
    }, m = [], E = !1, u = {
      state: p,
      setOptions: function(w) {
        var x = typeof w == "function" ? w(p.options) : w;
        v(), p.options = Object.assign({}, i, p.options, x), p.scrollParents = {
          reference: J(s) ? ie(s) : s.contextElement ? ie(s.contextElement) : [],
          popper: ie(f)
        };
        var O = pr(ur([].concat(n, p.options.modifiers)));
        return p.orderedModifiers = O.filter(function(l) {
          return l.enabled;
        }), g(), u.update();
      },
      forceUpdate: function() {
        if (!E) {
          var w = p.elements, x = w.reference, O = w.popper;
          if (!!Ge(x, O)) {
            p.rects = {
              reference: sr(x, pe(O), p.options.strategy === "fixed"),
              popper: De(O)
            }, p.reset = !1, p.placement = p.options.placement, p.orderedModifiers.forEach(function(P) {
              return p.modifiersData[P.name] = Object.assign({}, P.data);
            });
            for (var l = 0; l < p.orderedModifiers.length; l++) {
              if (p.reset === !0) {
                p.reset = !1, l = -1;
                continue;
              }
              var y = p.orderedModifiers[l], h = y.fn, b = y.options, A = b === void 0 ? {} : b, j = y.name;
              typeof h == "function" && (p = h({
                state: p,
                options: A,
                name: j,
                instance: u
              }) || p);
            }
          }
        }
      },
      update: cr(function() {
        return new Promise(function(d) {
          u.forceUpdate(), d(p);
        });
      }),
      destroy: function() {
        v(), E = !0;
      }
    };
    if (!Ge(s, f))
      return u;
    u.setOptions(c).then(function(d) {
      !E && c.onFirstUpdate && c.onFirstUpdate(d);
    });
    function g() {
      p.orderedModifiers.forEach(function(d) {
        var w = d.name, x = d.options, O = x === void 0 ? {} : x, l = d.effect;
        if (typeof l == "function") {
          var y = l({
            state: p,
            name: w,
            instance: u,
            options: O
          }), h = function() {
          };
          m.push(y || h);
        }
      });
    }
    function v() {
      m.forEach(function(d) {
        return d();
      }), m = [];
    }
    return u;
  };
}
var vr = [Mt, er, Tt, Et, Zt, Ut, nr, Ct, Jt], dr = /* @__PURE__ */ lr({
  defaultModifiers: vr
});
export {
  dr as c
};
//# sourceMappingURL=@popperjs.0fa98044.js.map
