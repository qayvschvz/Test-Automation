function i(s, a) {
  return s.classList ? !!a && s.classList.contains(a) : (" " + (s.className.baseVal || s.className) + " ").indexOf(" " + a + " ") !== -1;
}
function r(s, a) {
  s.classList ? s.classList.add(a) : i(s, a) || (typeof s.className == "string" ? s.className = s.className + " " + a : s.setAttribute("class", (s.className && s.className.baseVal || "") + " " + a));
}
function c(s, a) {
  return s.replace(new RegExp("(^|\\s)" + a + "(?:\\s|$)", "g"), "$1").replace(/\s+/g, " ").replace(/^\s*|\s*$/g, "");
}
function f(s, a) {
  s.classList ? s.classList.remove(a) : typeof s.className == "string" ? s.className = c(s.className, a) : s.setAttribute("class", c(s.className && s.className.baseVal || "", a));
}
export {
  r as a,
  f as r
};
//# sourceMappingURL=dom-helpers.2bf980ac.js.map
