import { _ as o } from "./@babel.7bf9beb3.js";
var g = /\s*,\s*/g, S = /&/g, m = /\$([\w-]+)/g;
function L() {
  function R(n, a) {
    return function(i, e) {
      var r = n.getRule(e) || a && a.getRule(e);
      return r ? r.selector : e;
    };
  }
  function d(n, a) {
    for (var i = a.split(g), e = n.split(g), r = "", f = 0; f < i.length; f++)
      for (var l = i[f], t = 0; t < e.length; t++) {
        var u = e[t];
        r && (r += ", "), r += u.indexOf("&") !== -1 ? u.replace(S, l) : l + " " + u;
      }
    return r;
  }
  function x(n, a, i) {
    if (i)
      return o({}, i, {
        index: i.index + 1
      });
    var e = n.options.nestingLevel;
    e = e === void 0 ? 1 : e + 1;
    var r = o({}, n.options, {
      nestingLevel: e,
      index: a.indexOf(n) + 1
    });
    return delete r.name, r;
  }
  function p(n, a, i) {
    if (a.type !== "style")
      return n;
    var e = a, r = e.options.parent, f, l;
    for (var t in n) {
      var u = t.indexOf("&") !== -1, v = t[0] === "@";
      if (!(!u && !v)) {
        if (f = x(e, r, f), u) {
          var c = d(t, e.selector);
          l || (l = R(r, i)), c = c.replace(m, l);
          var s = e.key + "-" + t;
          "replaceRule" in r ? r.replaceRule(s, n[t], o({}, f, {
            selector: c
          })) : r.addRule(s, n[t], o({}, f, {
            selector: c
          }));
        } else
          v && r.addRule(t, {}, f).addRule(e.key, n[t], {
            selector: e.selector
          });
        delete n[t];
      }
    }
    return n;
  }
  return {
    onProcessStyle: p
  };
}
export {
  L as j
};
//# sourceMappingURL=jss-plugin-nested.1b37bc0b.js.map
