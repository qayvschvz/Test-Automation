const A = () => /* @__PURE__ */ Object.create(null), { forEach: S, slice: O } = Array.prototype, { hasOwnProperty: C } = Object.prototype;
class m {
  constructor(e = !0, n = A) {
    this.weakness = e, this.makeData = n;
  }
  lookup(...e) {
    return this.lookupArray(e);
  }
  lookupArray(e) {
    let n = this;
    return S.call(e, (s) => n = n.getChildTrie(s)), C.call(n, "data") ? n.data : n.data = this.makeData(O.call(e));
  }
  peek(...e) {
    return this.peekArray(e);
  }
  peekArray(e) {
    let n = this;
    for (let s = 0, r = e.length; n && s < r; ++s) {
      const i = this.weakness && y(e[s]) ? n.weak : n.strong;
      n = i && i.get(e[s]);
    }
    return n && n.data;
  }
  getChildTrie(e) {
    const n = this.weakness && y(e) ? this.weak || (this.weak = /* @__PURE__ */ new WeakMap()) : this.strong || (this.strong = /* @__PURE__ */ new Map());
    let s = n.get(e);
    return s || n.set(e, s = new m(this.weakness, this.makeData)), s;
  }
}
function y(t) {
  switch (typeof t) {
    case "object":
      if (t === null)
        break;
    case "function":
      return !0;
  }
  return !1;
}
const { toString: p, hasOwnProperty: x } = Object.prototype, d = Function.prototype.toString, f = /* @__PURE__ */ new Map();
function K(t, e) {
  try {
    return h(t, e);
  } finally {
    f.clear();
  }
}
function h(t, e) {
  if (t === e)
    return !0;
  const n = p.call(t), s = p.call(e);
  if (n !== s)
    return !1;
  switch (n) {
    case "[object Array]":
      if (t.length !== e.length)
        return !1;
    case "[object Object]": {
      if (j(t, e))
        return !0;
      const r = g(t), i = g(e), c = r.length;
      if (c !== i.length)
        return !1;
      for (let a = 0; a < c; ++a)
        if (!x.call(e, r[a]))
          return !1;
      for (let a = 0; a < c; ++a) {
        const l = r[a];
        if (!h(t[l], e[l]))
          return !1;
      }
      return !0;
    }
    case "[object Error]":
      return t.name === e.name && t.message === e.message;
    case "[object Number]":
      if (t !== t)
        return e !== e;
    case "[object Boolean]":
    case "[object Date]":
      return +t == +e;
    case "[object RegExp]":
    case "[object String]":
      return t == `${e}`;
    case "[object Map]":
    case "[object Set]": {
      if (t.size !== e.size)
        return !1;
      if (j(t, e))
        return !0;
      const r = t.entries(), i = n === "[object Map]";
      for (; ; ) {
        const c = r.next();
        if (c.done)
          break;
        const [a, l] = c.value;
        if (!e.has(a) || i && !h(l, e.get(a)))
          return !1;
      }
      return !0;
    }
    case "[object Uint16Array]":
    case "[object Uint8Array]":
    case "[object Uint32Array]":
    case "[object Int32Array]":
    case "[object Int8Array]":
    case "[object Int16Array]":
    case "[object ArrayBuffer]":
      t = new Uint8Array(t), e = new Uint8Array(e);
    case "[object DataView]": {
      let r = t.byteLength;
      if (r === e.byteLength)
        for (; r-- && t[r] === e[r]; )
          ;
      return r === -1;
    }
    case "[object AsyncFunction]":
    case "[object GeneratorFunction]":
    case "[object AsyncGeneratorFunction]":
    case "[object Function]": {
      const r = d.call(t);
      return r !== d.call(e) ? !1 : !D(r, M);
    }
  }
  return !1;
}
function g(t) {
  return Object.keys(t).filter(v, t);
}
function v(t) {
  return this[t] !== void 0;
}
const M = "{ [native code] }";
function D(t, e) {
  const n = t.length - e.length;
  return n >= 0 && t.indexOf(e, n) === n;
}
function j(t, e) {
  let n = f.get(t);
  if (n) {
    if (n.has(e))
      return !0;
  } else
    f.set(t, n = /* @__PURE__ */ new Set());
  return n.add(e), !1;
}
let o = null;
const b = {};
let I = 1;
const T = () => class {
  constructor() {
    this.id = [
      "slot",
      I++,
      Date.now(),
      Math.random().toString(36).slice(2)
    ].join(":");
  }
  hasValue() {
    for (let e = o; e; e = e.parent)
      if (this.id in e.slots) {
        const n = e.slots[this.id];
        if (n === b)
          break;
        return e !== o && (o.slots[this.id] = n), !0;
      }
    return o && (o.slots[this.id] = b), !1;
  }
  getValue() {
    if (this.hasValue())
      return o.slots[this.id];
  }
  withValue(e, n, s, r) {
    const i = {
      __proto__: null,
      [this.id]: e
    }, c = o;
    o = { parent: c, slots: i };
    try {
      return n.apply(r, s);
    } finally {
      o = c;
    }
  }
  static bind(e) {
    const n = o;
    return function() {
      const s = o;
      try {
        return o = n, e.apply(this, arguments);
      } finally {
        o = s;
      }
    };
  }
  static noContext(e, n, s) {
    if (o) {
      const r = o;
      try {
        return o = null, e.apply(s, n);
      } finally {
        o = r;
      }
    } else
      return e.apply(s, n);
  }
};
function w(t) {
  try {
    return t();
  } catch {
  }
}
const u = "@wry/context:Slot", V = w(() => globalThis) || w(() => global) || /* @__PURE__ */ Object.create(null), k = V, F = k[u] || Array[u] || function(t) {
  try {
    Object.defineProperty(k, u, {
      value: t,
      enumerable: !1,
      writable: !1,
      configurable: !0
    });
  } finally {
    return t;
  }
}(T());
export {
  F as S,
  m as T,
  K as e
};
//# sourceMappingURL=@wry.a2a6dbbf.js.map
