import { h as o } from "./hyphenate-style-name.72ef4282.js";
function e(n) {
  var f = {};
  for (var r in n) {
    var a = r.indexOf("--") === 0 ? r : o(r);
    f[a] = n[r];
  }
  return n.fallbacks && (Array.isArray(n.fallbacks) ? f.fallbacks = n.fallbacks.map(e) : f.fallbacks = e(n.fallbacks)), f;
}
function t() {
  function n(r) {
    if (Array.isArray(r)) {
      for (var a = 0; a < r.length; a++)
        r[a] = e(r[a]);
      return r;
    }
    return e(r);
  }
  function f(r, a, i) {
    if (a.indexOf("--") === 0)
      return r;
    var c = o(a);
    return a === c ? r : (i.prop(c, r), null);
  }
  return {
    onProcessStyle: n,
    onChangeValue: f
  };
}
export {
  t as c
};
//# sourceMappingURL=jss-plugin-camel-case.bf52bd77.js.map
