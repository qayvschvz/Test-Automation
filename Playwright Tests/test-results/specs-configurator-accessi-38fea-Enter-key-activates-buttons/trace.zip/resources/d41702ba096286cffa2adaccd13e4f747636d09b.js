var g = { exports: {} };
g.exports = function(t) {
  return c(d(t), t);
};
g.exports.array = c;
function c(t, r) {
  var n = t.length, e = new Array(n), o = {}, i = n, y = k(r), s = p(t);
  for (r.forEach(function(a) {
    if (!s.has(a[0]) || !s.has(a[1]))
      throw new Error("Unknown node. There is an unknown node in the supplied edges.");
  }); i--; )
    o[i] || v(t[i], i, /* @__PURE__ */ new Set());
  return e;
  function v(a, u, f) {
    if (f.has(a)) {
      var w;
      try {
        w = ", node was:" + JSON.stringify(a);
      } catch {
        w = "";
      }
      throw new Error("Cyclic dependency" + w);
    }
    if (!s.has(a))
      throw new Error("Found unknown node. Make sure to provided all involved nodes. Unknown node: " + JSON.stringify(a));
    if (!o[u]) {
      o[u] = !0;
      var h = y.get(a) || /* @__PURE__ */ new Set();
      if (h = Array.from(h), u = h.length) {
        f.add(a);
        do {
          var l = h[--u];
          v(l, s.get(l), f);
        } while (u);
        f.delete(a);
      }
      e[--n] = a;
    }
  }
}
function d(t) {
  for (var r = /* @__PURE__ */ new Set(), n = 0, e = t.length; n < e; n++) {
    var o = t[n];
    r.add(o[0]), r.add(o[1]);
  }
  return Array.from(r);
}
function k(t) {
  for (var r = /* @__PURE__ */ new Map(), n = 0, e = t.length; n < e; n++) {
    var o = t[n];
    r.has(o[0]) || r.set(o[0], /* @__PURE__ */ new Set()), r.has(o[1]) || r.set(o[1], /* @__PURE__ */ new Set()), r.get(o[0]).add(o[1]);
  }
  return r;
}
function p(t) {
  for (var r = /* @__PURE__ */ new Map(), n = 0, e = t.length; n < e; n++)
    r.set(t[n], n);
  return r;
}
export {
  g as t
};
//# sourceMappingURL=toposort.b127f7a4.js.map
