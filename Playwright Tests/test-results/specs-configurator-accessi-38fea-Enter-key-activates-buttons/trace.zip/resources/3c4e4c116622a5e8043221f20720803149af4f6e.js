var s = (b, e) => () => (e || b((e = { exports: {} }).exports, e), e.exports);
var t = s((a, f) => {
  function n(b) {
    var e, o = b.Symbol;
    if (typeof o == "function")
      if (o.observable)
        e = o.observable;
      else {
        typeof o.for == "function" ? e = o.for("https://github.com/benlesh/symbol-observable") : e = o("https://github.com/benlesh/symbol-observable");
        try {
          o.observable = e;
        } catch {
        }
      }
    else
      e = "@@observable";
    return e;
  }
  var l;
  typeof self < "u" ? l = self : typeof window < "u" ? l = window : typeof global < "u" ? l = global : typeof f < "u" ? l = f : l = Function("return this")();
  n(l);
});
export default t();
//# sourceMappingURL=symbol-observable.fd2d5738.js.map
