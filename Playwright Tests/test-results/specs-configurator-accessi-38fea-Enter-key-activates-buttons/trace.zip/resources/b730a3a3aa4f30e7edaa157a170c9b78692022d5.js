var f, v;
function b() {
  if (v)
    return f;
  v = 1;
  function a(t) {
    this.options = t, !t.deferSetup && this.setup();
  }
  return a.prototype = {
    constructor: a,
    setup: function() {
      this.options.setup && this.options.setup(), this.initialised = !0;
    },
    on: function() {
      !this.initialised && this.setup(), this.options.match && this.options.match();
    },
    off: function() {
      this.options.unmatch && this.options.unmatch();
    },
    destroy: function() {
      this.options.destroy ? this.options.destroy() : this.off();
    },
    equals: function(t) {
      return this.options === t || this.options.match === t;
    }
  }, f = a, f;
}
var d, m;
function M() {
  if (m)
    return d;
  m = 1;
  function a(e, n) {
    var i = 0, r = e.length, s;
    for (i; i < r && (s = n(e[i], i), s !== !1); i++)
      ;
  }
  function t(e) {
    return Object.prototype.toString.apply(e) === "[object Array]";
  }
  function u(e) {
    return typeof e == "function";
  }
  return d = {
    isFunction: u,
    isArray: t,
    each: a
  }, d;
}
var l, q;
function g() {
  if (q)
    return l;
  q = 1;
  var a = b(), t = M().each;
  function u(e, n) {
    this.query = e, this.isUnconditional = n, this.handlers = [], this.mql = window.matchMedia(e);
    var i = this;
    this.listener = function(r) {
      i.mql = r.currentTarget || r, i.assess();
    }, this.mql.addListener(this.listener);
  }
  return u.prototype = {
    constuctor: u,
    addHandler: function(e) {
      var n = new a(e);
      this.handlers.push(n), this.matches() && n.on();
    },
    removeHandler: function(e) {
      var n = this.handlers;
      t(n, function(i, r) {
        if (i.equals(e))
          return i.destroy(), !n.splice(r, 1);
      });
    },
    matches: function() {
      return this.mql.matches || this.isUnconditional;
    },
    clear: function() {
      t(this.handlers, function(e) {
        e.destroy();
      }), this.mql.removeListener(this.listener), this.handlers.length = 0;
    },
    assess: function() {
      var e = this.matches() ? "on" : "off";
      t(this.handlers, function(n) {
        n[e]();
      });
    }
  }, l = u, l;
}
var y, Q;
function U() {
  if (Q)
    return y;
  Q = 1;
  var a = g(), t = M(), u = t.each, e = t.isFunction, n = t.isArray;
  function i() {
    if (!window.matchMedia)
      throw new Error("matchMedia not present, legacy browsers require a polyfill");
    this.queries = {}, this.browserIsIncapable = !window.matchMedia("only all").matches;
  }
  return i.prototype = {
    constructor: i,
    register: function(r, s, o) {
      var c = this.queries, H = o && this.browserIsIncapable;
      return c[r] || (c[r] = new a(r, H)), e(s) && (s = { match: s }), n(s) || (s = [s]), u(s, function(h) {
        e(h) && (h = { match: h }), c[r].addHandler(h);
      }), this;
    },
    unregister: function(r, s) {
      var o = this.queries[r];
      return o && (s ? o.removeHandler(s) : (o.clear(), delete this.queries[r])), this;
    }
  }, y = i, y;
}
var p, w;
function A() {
  if (w)
    return p;
  w = 1;
  var a = U();
  return p = new a(), p;
}
export {
  A as r
};
//# sourceMappingURL=enquire.js.69628d15.js.map
