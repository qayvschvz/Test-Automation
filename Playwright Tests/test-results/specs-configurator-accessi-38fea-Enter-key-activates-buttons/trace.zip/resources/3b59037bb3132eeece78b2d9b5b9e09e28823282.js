import { b, a as h, _ as w } from "./tslib.0d11ab8c.js";
import { i as D, a as P, b as U, c as z, d as G, e as V, f as R, g as x, h as k, j as Z, k as C, p as X, m as T, s as A } from "./@formatjs.8b514567.js";
var g;
(function(t) {
  t.MISSING_VALUE = "MISSING_VALUE", t.INVALID_VALUE = "INVALID_VALUE", t.MISSING_INTL_API = "MISSING_INTL_API";
})(g || (g = {}));
var L = function(t) {
  b(e, t);
  function e(r, n, a) {
    var u = t.call(this, r) || this;
    return u.code = n, u.originalMessage = a, u;
  }
  return e.prototype.toString = function() {
    return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
  }, e;
}(Error), j = function(t) {
  b(e, t);
  function e(r, n, a, u) {
    return t.call(this, 'Invalid values for "'.concat(r, '": "').concat(n, '". Options are "').concat(Object.keys(a).join('", "'), '"'), g.INVALID_VALUE, u) || this;
  }
  return e;
}(L), q = function(t) {
  b(e, t);
  function e(r, n, a) {
    return t.call(this, 'Value for "'.concat(r, '" must be of type ').concat(n), g.INVALID_VALUE, a) || this;
  }
  return e;
}(L), B = function(t) {
  b(e, t);
  function e(r, n) {
    return t.call(this, 'The intl string context variable "'.concat(r, '" was not provided to the string "').concat(n, '"'), g.MISSING_VALUE, n) || this;
  }
  return e;
}(L), m;
(function(t) {
  t[t.literal = 0] = "literal", t[t.object = 1] = "object";
})(m || (m = {}));
function H(t) {
  return t.length < 2 ? t : t.reduce(function(e, r) {
    var n = e[e.length - 1];
    return !n || n.type !== m.literal || r.type !== m.literal ? e.push(r) : n.value += r.value, e;
  }, []);
}
function J(t) {
  return typeof t == "function";
}
function I(t, e, r, n, a, u, f) {
  if (t.length === 1 && D(t[0]))
    return [
      {
        type: m.literal,
        value: t[0].value
      }
    ];
  for (var s = [], p = 0, c = t; p < c.length; p++) {
    var i = c[p];
    if (D(i)) {
      s.push({
        type: m.literal,
        value: i.value
      });
      continue;
    }
    if (P(i)) {
      typeof u == "number" && s.push({
        type: m.literal,
        value: r.getNumberFormat(e).format(u)
      });
      continue;
    }
    var E = i.value;
    if (!(a && E in a))
      throw new B(E, f);
    var o = a[E];
    if (U(i)) {
      (!o || typeof o == "string" || typeof o == "number") && (o = typeof o == "string" || typeof o == "number" ? String(o) : ""), s.push({
        type: typeof o == "string" ? m.literal : m.object,
        value: o
      });
      continue;
    }
    if (z(i)) {
      var l = typeof i.style == "string" ? n.date[i.style] : V(i.style) ? i.style.parsedOptions : void 0;
      s.push({
        type: m.literal,
        value: r.getDateTimeFormat(e, l).format(o)
      });
      continue;
    }
    if (G(i)) {
      var l = typeof i.style == "string" ? n.time[i.style] : V(i.style) ? i.style.parsedOptions : n.time.medium;
      s.push({
        type: m.literal,
        value: r.getDateTimeFormat(e, l).format(o)
      });
      continue;
    }
    if (R(i)) {
      var l = typeof i.style == "string" ? n.number[i.style] : x(i.style) ? i.style.parsedOptions : void 0;
      l && l.scale && (o = o * (l.scale || 1)), s.push({
        type: m.literal,
        value: r.getNumberFormat(e, l).format(o)
      });
      continue;
    }
    if (k(i)) {
      var _ = i.children, F = i.value, S = a[F];
      if (!J(S))
        throw new q(F, "function", f);
      var O = I(_, e, r, n, a, u), d = S(O.map(function(v) {
        return v.value;
      }));
      Array.isArray(d) || (d = [d]), s.push.apply(s, d.map(function(v) {
        return {
          type: typeof v == "string" ? m.literal : m.object,
          value: v
        };
      }));
    }
    if (Z(i)) {
      var y = i.options[o] || i.options.other;
      if (!y)
        throw new j(i.value, o, Object.keys(i.options), f);
      s.push.apply(s, I(y.value, e, r, n, a));
      continue;
    }
    if (C(i)) {
      var y = i.options["=".concat(o)];
      if (!y) {
        if (!Intl.PluralRules)
          throw new L(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, g.MISSING_INTL_API, f);
        var M = r.getPluralRules(e, { type: i.pluralType }).select(o - (i.offset || 0));
        y = i.options[M] || i.options.other;
      }
      if (!y)
        throw new j(i.value, o, Object.keys(i.options), f);
      s.push.apply(s, I(y.value, e, r, n, a, o - (i.offset || 0)));
      continue;
    }
  }
  return H(s);
}
function K(t, e) {
  return e ? h(h(h({}, t || {}), e || {}), Object.keys(t).reduce(function(r, n) {
    return r[n] = h(h({}, t[n]), e[n] || {}), r;
  }, {})) : t;
}
function Q(t, e) {
  return e ? Object.keys(t).reduce(function(r, n) {
    return r[n] = K(t[n], e[n]), r;
  }, h({}, t)) : t;
}
function N(t) {
  return {
    create: function() {
      return {
        get: function(e) {
          return t[e];
        },
        set: function(e, r) {
          t[e] = r;
        }
      };
    }
  };
}
function W(t) {
  return t === void 0 && (t = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: T(function() {
      for (var e, r = [], n = 0; n < arguments.length; n++)
        r[n] = arguments[n];
      return new ((e = Intl.NumberFormat).bind.apply(e, w([void 0], r, !1)))();
    }, {
      cache: N(t.number),
      strategy: A.variadic
    }),
    getDateTimeFormat: T(function() {
      for (var e, r = [], n = 0; n < arguments.length; n++)
        r[n] = arguments[n];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, w([void 0], r, !1)))();
    }, {
      cache: N(t.dateTime),
      strategy: A.variadic
    }),
    getPluralRules: T(function() {
      for (var e, r = [], n = 0; n < arguments.length; n++)
        r[n] = arguments[n];
      return new ((e = Intl.PluralRules).bind.apply(e, w([void 0], r, !1)))();
    }, {
      cache: N(t.pluralRules),
      strategy: A.variadic
    })
  };
}
var tt = function() {
  function t(e, r, n, a) {
    var u = this;
    if (r === void 0 && (r = t.defaultLocale), this.formatterCache = {
      number: {},
      dateTime: {},
      pluralRules: {}
    }, this.format = function(f) {
      var s = u.formatToParts(f);
      if (s.length === 1)
        return s[0].value;
      var p = s.reduce(function(c, i) {
        return !c.length || i.type !== m.literal || typeof c[c.length - 1] != "string" ? c.push(i.value) : c[c.length - 1] += i.value, c;
      }, []);
      return p.length <= 1 ? p[0] || "" : p;
    }, this.formatToParts = function(f) {
      return I(u.ast, u.locales, u.formatters, u.formats, f, void 0, u.message);
    }, this.resolvedOptions = function() {
      return {
        locale: u.resolvedLocale.toString()
      };
    }, this.getAst = function() {
      return u.ast;
    }, this.locales = r, this.resolvedLocale = t.resolveLocale(r), typeof e == "string") {
      if (this.message = e, !t.__parse)
        throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
      this.ast = t.__parse(e, {
        ignoreTag: a == null ? void 0 : a.ignoreTag,
        locale: this.resolvedLocale
      });
    } else
      this.ast = e;
    if (!Array.isArray(this.ast))
      throw new TypeError("A message must be provided as a String or AST.");
    this.formats = Q(t.formats, n), this.formatters = a && a.formatters || W(this.formatterCache);
  }
  return Object.defineProperty(t, "defaultLocale", {
    get: function() {
      return t.memoizedDefaultLocale || (t.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), t.memoizedDefaultLocale;
    },
    enumerable: !1,
    configurable: !0
  }), t.memoizedDefaultLocale = null, t.resolveLocale = function(e) {
    var r = Intl.NumberFormat.supportedLocalesOf(e);
    return r.length > 0 ? new Intl.Locale(r[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
  }, t.__parse = X, t.formats = {
    number: {
      integer: {
        maximumFractionDigits: 0
      },
      currency: {
        style: "currency"
      },
      percent: {
        style: "percent"
      }
    },
    date: {
      short: {
        month: "numeric",
        day: "numeric",
        year: "2-digit"
      },
      medium: {
        month: "short",
        day: "numeric",
        year: "numeric"
      },
      long: {
        month: "long",
        day: "numeric",
        year: "numeric"
      },
      full: {
        weekday: "long",
        month: "long",
        day: "numeric",
        year: "numeric"
      }
    },
    time: {
      short: {
        hour: "numeric",
        minute: "numeric"
      },
      medium: {
        hour: "numeric",
        minute: "numeric",
        second: "numeric"
      },
      long: {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        timeZoneName: "short"
      },
      full: {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        timeZoneName: "short"
      }
    }
  }, t;
}();
export {
  g as E,
  L as F,
  tt as I,
  J as i
};
//# sourceMappingURL=intl-messageformat.eb8c2d83.js.map
