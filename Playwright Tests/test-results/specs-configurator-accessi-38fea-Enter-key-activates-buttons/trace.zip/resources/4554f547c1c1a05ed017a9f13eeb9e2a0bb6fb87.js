var i;
try {
  i = Map;
} catch {
}
var o;
try {
  o = Set;
} catch {
}
function u(e, n, t) {
  if (!e || typeof e != "object" || typeof e == "function")
    return e;
  if (e.nodeType && "cloneNode" in e)
    return e.cloneNode(!0);
  if (e instanceof Date)
    return new Date(e.getTime());
  if (e instanceof RegExp)
    return new RegExp(e);
  if (Array.isArray(e))
    return e.map(y);
  if (i && e instanceof i)
    return new Map(Array.from(e.entries()));
  if (o && e instanceof o)
    return new Set(Array.from(e.values()));
  if (e instanceof Object) {
    n.push(e);
    var a = Object.create(e);
    t.push(a);
    for (var f in e) {
      var r = n.findIndex(function(p) {
        return p === e[f];
      });
      a[f] = r > -1 ? t[r] : u(e[f], n, t);
    }
    return a;
  }
  return e;
}
function y(e) {
  return u(e, [], []);
}
export {
  y as c
};
//# sourceMappingURL=nanoclone.b9584726.js.map
