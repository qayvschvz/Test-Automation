var O = function(s, f) {
  f || (f = {}), typeof f == "function" && (f = { cmp: f });
  var v = typeof f.cycles == "boolean" ? f.cycles : !1, a = f.cmp && function(n) {
    return function(r) {
      return function(i, t) {
        var c = { key: i, value: r[i] }, u = { key: t, value: r[t] };
        return n(c, u);
      };
    };
  }(f.cmp), e = [];
  return function n(r) {
    if (r && r.toJSON && typeof r.toJSON == "function" && (r = r.toJSON()), r !== void 0) {
      if (typeof r == "number")
        return isFinite(r) ? "" + r : "null";
      if (typeof r != "object")
        return JSON.stringify(r);
      var i, t;
      if (Array.isArray(r)) {
        for (t = "[", i = 0; i < r.length; i++)
          i && (t += ","), t += n(r[i]) || "null";
        return t + "]";
      }
      if (r === null)
        return "null";
      if (e.indexOf(r) !== -1) {
        if (v)
          return JSON.stringify("__cycle__");
        throw new TypeError("Converting circular structure to JSON");
      }
      var c = e.push(r) - 1, u = Object.keys(r).sort(a && a(r));
      for (t = "", i = 0; i < u.length; i++) {
        var l = u[i], y = n(r[l]);
        !y || (t && (t += ","), t += JSON.stringify(l) + ":" + y);
      }
      return e.splice(c, 1), "{" + t + "}";
    }
  }(s);
};
export {
  O as f
};
//# sourceMappingURL=fast-json-stable-stringify.ec72e098.js.map
