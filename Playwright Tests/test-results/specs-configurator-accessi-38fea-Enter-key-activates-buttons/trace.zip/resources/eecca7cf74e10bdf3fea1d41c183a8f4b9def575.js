import { S as I, T as x } from "./@wry.a2a6dbbf.js";
function B() {
}
class G {
  constructor(t = 1 / 0, s = B) {
    this.max = t, this.dispose = s, this.map = /* @__PURE__ */ new Map(), this.newest = null, this.oldest = null;
  }
  has(t) {
    return this.map.has(t);
  }
  get(t) {
    const s = this.getNode(t);
    return s && s.value;
  }
  getNode(t) {
    const s = this.map.get(t);
    if (s && s !== this.newest) {
      const { older: i, newer: u } = s;
      u && (u.older = i), i && (i.newer = u), s.older = this.newest, s.older.newer = s, s.newer = null, this.newest = s, s === this.oldest && (this.oldest = u);
    }
    return s;
  }
  set(t, s) {
    let i = this.getNode(t);
    return i ? i.value = s : (i = {
      key: t,
      value: s,
      newer: null,
      older: this.newest
    }, this.newest && (this.newest.newer = i), this.newest = i, this.oldest = this.oldest || i, this.map.set(t, i), i.value);
  }
  clean() {
    for (; this.oldest && this.map.size > this.max; )
      this.delete(this.oldest.key);
  }
  delete(t) {
    const s = this.map.get(t);
    return s ? (s === this.newest && (this.newest = s.older), s === this.oldest && (this.oldest = s.newer), s.newer && (s.newer.older = s.older), s.older && (s.older.newer = s.newer), this.map.delete(t), this.dispose(s.value, t), !0) : !1;
  }
}
const y = new I(), { hasOwnProperty: N } = Object.prototype, b = Array.from || function(e) {
  const t = [];
  return e.forEach((s) => t.push(s)), t;
};
function w(e) {
  const { unsubscribe: t } = e;
  typeof t == "function" && (e.unsubscribe = void 0, t());
}
const h = [], R = 100;
function a(e, t) {
  if (!e)
    throw new Error(t || "assertion failure");
}
function W(e, t) {
  const s = e.length;
  return s > 0 && s === t.length && e[s - 1] === t[s - 1];
}
function D(e) {
  switch (e.length) {
    case 0:
      throw new Error("unknown value");
    case 1:
      return e[0];
    case 2:
      throw e[1];
  }
}
function _(e) {
  return e.slice(0);
}
class g {
  constructor(t) {
    this.fn = t, this.parents = /* @__PURE__ */ new Set(), this.childValues = /* @__PURE__ */ new Map(), this.dirtyChildren = null, this.dirty = !0, this.recomputing = !1, this.value = [], this.deps = null, ++g.count;
  }
  peek() {
    if (this.value.length === 1 && !f(this))
      return C(this), this.value[0];
  }
  recompute(t) {
    return a(!this.recomputing, "already recomputing"), C(this), f(this) ? L(this, t) : D(this.value);
  }
  setDirty() {
    this.dirty || (this.dirty = !0, this.value.length = 0, S(this), w(this));
  }
  dispose() {
    this.setDirty(), j(this), v(this, (t, s) => {
      t.setDirty(), K(t, this);
    });
  }
  forget() {
    this.dispose();
  }
  dependOn(t) {
    t.add(this), this.deps || (this.deps = h.pop() || /* @__PURE__ */ new Set()), this.deps.add(t);
  }
  forgetDeps() {
    this.deps && (b(this.deps).forEach((t) => t.delete(this)), this.deps.clear(), h.push(this.deps), this.deps = null);
  }
}
g.count = 0;
function C(e) {
  const t = y.getValue();
  if (t)
    return e.parents.add(t), t.childValues.has(e) || t.childValues.set(e, []), f(e) ? z(t, e) : O(t, e), t;
}
function L(e, t) {
  return j(e), y.withValue(e, U, [e, t]), q(e, t) && Z(e), D(e.value);
}
function U(e, t) {
  e.recomputing = !0, e.value.length = 0;
  try {
    e.value[0] = e.fn.apply(null, t);
  } catch (s) {
    e.value[1] = s;
  }
  e.recomputing = !1;
}
function f(e) {
  return e.dirty || !!(e.dirtyChildren && e.dirtyChildren.size);
}
function Z(e) {
  e.dirty = !1, !f(e) && E(e);
}
function S(e) {
  v(e, z);
}
function E(e) {
  v(e, O);
}
function v(e, t) {
  const s = e.parents.size;
  if (s) {
    const i = b(e.parents);
    for (let u = 0; u < s; ++u)
      t(i[u], e);
  }
}
function z(e, t) {
  a(e.childValues.has(t)), a(f(t));
  const s = !f(e);
  if (!e.dirtyChildren)
    e.dirtyChildren = h.pop() || /* @__PURE__ */ new Set();
  else if (e.dirtyChildren.has(t))
    return;
  e.dirtyChildren.add(t), s && S(e);
}
function O(e, t) {
  a(e.childValues.has(t)), a(!f(t));
  const s = e.childValues.get(t);
  s.length === 0 ? e.childValues.set(t, _(t.value)) : W(s, t.value) || e.setDirty(), P(e, t), !f(e) && E(e);
}
function P(e, t) {
  const s = e.dirtyChildren;
  s && (s.delete(t), s.size === 0 && (h.length < R && h.push(s), e.dirtyChildren = null));
}
function j(e) {
  e.childValues.size > 0 && e.childValues.forEach((t, s) => {
    K(e, s);
  }), e.forgetDeps(), a(e.dirtyChildren === null);
}
function K(e, t) {
  t.parents.delete(e), e.childValues.delete(t), P(e, t);
}
function q(e, t) {
  if (typeof e.subscribe == "function")
    try {
      w(e), e.unsubscribe = e.subscribe.apply(null, t);
    } catch {
      return e.setDirty(), !1;
    }
  return !0;
}
const A = {
  setDirty: !0,
  dispose: !0,
  forget: !0
};
function J(e) {
  const t = /* @__PURE__ */ new Map(), s = e && e.subscribe;
  function i(u) {
    const l = y.getValue();
    if (l) {
      let n = t.get(u);
      n || t.set(u, n = /* @__PURE__ */ new Set()), l.dependOn(n), typeof s == "function" && (w(n), n.unsubscribe = s(u));
    }
  }
  return i.dirty = function(l, n) {
    const c = t.get(l);
    if (c) {
      const d = n && N.call(A, n) ? n : "setDirty";
      b(c).forEach((p) => p[d]()), t.delete(l), w(c);
    }
  }, i;
}
let V;
function F(...e) {
  return (V || (V = new x(typeof WeakMap == "function"))).lookupArray(e);
}
const m = /* @__PURE__ */ new Set();
function Q(e, { max: t = Math.pow(2, 16), makeCacheKey: s = F, keyArgs: i, subscribe: u } = /* @__PURE__ */ Object.create(null)) {
  const l = new G(t, (r) => r.dispose()), n = function() {
    const r = s.apply(null, i ? i.apply(null, arguments) : arguments);
    if (r === void 0)
      return e.apply(null, arguments);
    let o = l.get(r);
    o || (l.set(r, o = new g(e)), o.subscribe = u, o.forget = () => l.delete(r));
    const M = o.recompute(Array.prototype.slice.call(arguments));
    return l.set(r, o), m.add(l), y.hasValue() || (m.forEach((T) => T.clean()), m.clear()), M;
  };
  Object.defineProperty(n, "size", {
    get() {
      return l.map.size;
    },
    configurable: !1,
    enumerable: !1
  }), Object.freeze(n.options = {
    max: t,
    makeCacheKey: s,
    keyArgs: i,
    subscribe: u
  });
  function c(r) {
    const o = l.get(r);
    o && o.setDirty();
  }
  n.dirtyKey = c, n.dirty = function() {
    c(s.apply(null, arguments));
  };
  function d(r) {
    const o = l.get(r);
    if (o)
      return o.peek();
  }
  n.peekKey = d, n.peek = function() {
    return d(s.apply(null, arguments));
  };
  function p(r) {
    return l.delete(r);
  }
  return n.forgetKey = p, n.forget = function() {
    return p(s.apply(null, arguments));
  }, n.makeCacheKey = s, n.getKey = i ? function() {
    return s.apply(null, i.apply(null, arguments));
  } : s, Object.freeze(n);
}
export {
  J as d,
  Q as w
};
//# sourceMappingURL=optimism.9b69a115.js.map
