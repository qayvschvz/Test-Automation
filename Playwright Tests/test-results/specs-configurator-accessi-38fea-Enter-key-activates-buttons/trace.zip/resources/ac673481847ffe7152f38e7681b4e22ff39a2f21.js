var t = {}, n, i;
function f() {
  throw new Error("setTimeout has not been defined");
}
function h() {
  throw new Error("clearTimeout has not been defined");
}
(function() {
  try {
    typeof setTimeout == "function" ? n = setTimeout : n = f;
  } catch {
    n = f;
  }
  try {
    typeof clearTimeout == "function" ? i = clearTimeout : i = h;
  } catch {
    i = h;
  }
})();
function m(e) {
  if (n === setTimeout)
    return setTimeout(e, 0);
  if ((n === f || !n) && setTimeout)
    return n = setTimeout, setTimeout(e, 0);
  try {
    return n(e, 0);
  } catch {
    try {
      return n.call(null, e, 0);
    } catch {
      return n.call(this, e, 0);
    }
  }
}
function p(e) {
  if (i === clearTimeout)
    return clearTimeout(e);
  if ((i === h || !i) && clearTimeout)
    return i = clearTimeout, clearTimeout(e);
  try {
    return i(e);
  } catch {
    try {
      return i.call(null, e);
    } catch {
      return i.call(this, e);
    }
  }
}
var u = [], l = !1, c, s = -1;
function g() {
  !l || !c || (l = !1, c.length ? u = c.concat(u) : s = -1, u.length && T());
}
function T() {
  if (!l) {
    var e = m(g);
    l = !0;
    for (var r = u.length; r; ) {
      for (c = u, u = []; ++s < r; )
        c && c[s].run();
      s = -1, r = u.length;
    }
    c = null, l = !1, p(e);
  }
}
t.nextTick = function(e) {
  var r = new Array(arguments.length - 1);
  if (arguments.length > 1)
    for (var a = 1; a < arguments.length; a++)
      r[a - 1] = arguments[a];
  u.push(new d(e, r)), u.length === 1 && !l && m(T);
};
function d(e, r) {
  this.fun = e, this.array = r;
}
d.prototype.run = function() {
  this.fun.apply(null, this.array);
};
t.title = "browser";
t.browser = !0;
t.env = {};
t.argv = [];
t.version = "";
t.versions = {};
function o() {
}
t.on = o;
t.addListener = o;
t.once = o;
t.off = o;
t.removeListener = o;
t.removeAllListeners = o;
t.emit = o;
t.prependListener = o;
t.prependOnceListener = o;
t.listeners = function(e) {
  return [];
};
t.binding = function(e) {
  throw new Error("process.binding is not supported");
};
t.cwd = function() {
  return "/";
};
t.chdir = function(e) {
  throw new Error("process.chdir is not supported");
};
t.umask = function() {
  return 0;
};
//# sourceMappingURL=process.4b199dcc.js.map
